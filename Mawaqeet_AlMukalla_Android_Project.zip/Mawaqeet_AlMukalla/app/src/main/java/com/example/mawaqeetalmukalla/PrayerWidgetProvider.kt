package com.example.mawaqeetalmukalla

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.widget.RemoteViews
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

class PrayerWidgetProvider : AppWidgetProvider() {
    override fun onEnabled(context: Context) {
        val request = PeriodicWorkRequestBuilder<PrayerWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "prayer_times_refresh", ExistingPeriodicWorkPolicy.UPDATE, request
        )
        Thread {
            PrayerRepository.refresh(context)
            updateAll(context)
        }.start()
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateWidget(context, manager, it) }
        val request = PeriodicWorkRequestBuilder<PrayerWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "prayer_times_refresh", ExistingPeriodicWorkPolicy.KEEP, request
        )
        if (PrayerRepository.storedTimes(context).isEmpty()) {
            Thread {
                PrayerRepository.refresh(context)
                updateAll(context)
            }.start()
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH) {
            Thread {
                PrayerRepository.refresh(context)
                updateAll(context)
            }.start()
        }
    }

    companion object {
        const val ACTION_REFRESH = "com.example.mawaqeetalmukalla.REFRESH"

        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, PrayerWidgetProvider::class.java))
            ids.forEach { updateWidget(context, manager, it) }
        }

        private fun updateWidget(context: Context, manager: AppWidgetManager, id: Int) {
            val views = RemoteViews(context.packageName, R.layout.prayer_widget)
            val times = PrayerRepository.storedTimes(context)
            if (times.size < 5) {
                views.setTextViewText(R.id.next_prayer, "جارٍ جلب مواقيت الصلاة")
                views.setTextViewText(R.id.countdown, "--:--")
                manager.updateAppWidget(id, views)
                return
            }

            val keys = listOf("Fajr", "Dhuhr", "Asr", "Maghrib", "Isha")
            val names = listOf("الفجر", "الظهر", "العصر", "المغرب", "العشاء")
            val zone = TimeZone.getTimeZone("Asia/Aden")
            val now = Calendar.getInstance(zone)
            val nowMillis = now.timeInMillis
            var displayIndex = -1
            var targetMillis = 0L
            var countdownLabel = "متبقي على الأذان"
            var title = ""

            // إذا كان الوقت داخل الفترة بين الأذان والإقامة، يصبح العد التنازلي للإقامة.
            for (i in keys.indices) {
                val parts = times[keys[i]]!!.split(":")
                val adhan = Calendar.getInstance(zone).apply {
                    set(Calendar.HOUR_OF_DAY, parts[0].toInt())
                    set(Calendar.MINUTE, parts[1].toInt())
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }.timeInMillis
                val iqamaEnd = adhan + PrayerRepository.iqamaMinutes(context, keys[i]) * 60_000L
                if (nowMillis >= adhan && nowMillis < iqamaEnd) {
                    displayIndex = i
                    targetMillis = iqamaEnd
                    countdownLabel = "متبقي للإقامة"
                    title = "بعد أذان ${names[i]}"
                    break
                }
            }

            // إذا لم نكن بين الأذان والإقامة، نبحث عن الصلاة القادمة.
            if (displayIndex == -1) {
                for (i in keys.indices) {
                    val parts = times[keys[i]]!!.split(":")
                    val target = Calendar.getInstance(zone).apply {
                        set(Calendar.HOUR_OF_DAY, parts[0].toInt())
                        set(Calendar.MINUTE, parts[1].toInt())
                        set(Calendar.SECOND, 0)
                        set(Calendar.MILLISECOND, 0)
                    }
                    if (target.timeInMillis > nowMillis) {
                        displayIndex = i
                        targetMillis = target.timeInMillis
                        break
                    }
                }
                if (displayIndex == -1) {
                    displayIndex = 0
                    val parts = times[keys[0]]!!.split(":")
                    targetMillis = Calendar.getInstance(zone).apply {
                        add(Calendar.DAY_OF_YEAR, 1)
                        set(Calendar.HOUR_OF_DAY, parts[0].toInt())
                        set(Calendar.MINUTE, parts[1].toInt())
                        set(Calendar.SECOND, 0)
                        set(Calendar.MILLISECOND, 0)
                    }.timeInMillis
                }
                title = "الصلاة القادمة: ${names[displayIndex]}"
            }

            val remaining = (targetMillis - System.currentTimeMillis()).coerceAtLeast(0L)
            views.setTextViewText(R.id.next_prayer, title)
            views.setChronometer(R.id.countdown, SystemClock.elapsedRealtime() + remaining, "%s", true)
            views.setChronometerCountDown(R.id.countdown, true)
            views.setTextViewText(R.id.countdown_label, countdownLabel)

            val formatted = keys.indices.joinToString("     ") { i ->
                "${names[i]} ${toArabicDigits(times[keys[i]]!!)}"
            }
            views.setTextViewText(R.id.prayer_list, formatted)

            val iqama = PrayerRepository.iqamaMinutes(context, keys[displayIndex])
            views.setTextViewText(R.id.iqama, "مدة الأذان إلى الإقامة: $iqama دقيقة")

            manager.updateAppWidget(id, views)
        }

        private fun toArabicDigits(value: String): String {
            val digits = "٠١٢٣٤٥٦٧٨٩"
            return value.map { if (it in '0'..'9') digits[it - '0'] else it }.joinToString("")
        }
    }
}
