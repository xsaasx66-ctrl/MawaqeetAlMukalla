package com.example.mawaqeetalmukalla

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters

class PrayerWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        PrayerRepository.refresh(applicationContext)
        PrayerWidgetProvider.updateAll(applicationContext)
        return Result.success()
    }
}
