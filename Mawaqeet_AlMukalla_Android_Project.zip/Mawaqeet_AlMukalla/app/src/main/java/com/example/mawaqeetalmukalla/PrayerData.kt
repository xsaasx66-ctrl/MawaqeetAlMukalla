package com.example.mawaqeetalmukalla

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

data class Prayer(val name: String, val time: String, val iqamaMinutes: Int)

object PrayerData {
    val names = listOf("الفجر", "الظهر", "العصر", "المغرب", "العشاء")
    private val keys = listOf("Fajr", "Dhuhr", "Asr", "Maghrib", "Isha")
    private val defaults = listOf(20, 15, 15, 10, 15)

    fun parseTimes(json: String): Map<String, String> {
        val result = mutableMapOf<String, String>()
        for (key in keys) {
            val regex = Regex("\"$key\"\\s*:\\s*\"(\\d{1,2}:\\d{2})")
            val value = regex.find(json)?.groupValues?.getOrNull(1)
            if (value != null) result[key] = value
        }
        return result
    }

    fun keyForName(name: String): String = keys[names.indexOf(name).coerceAtLeast(0)]

    fun todayDate(): String = SimpleDateFormat("dd-MM-yyyy", Locale.US).apply { timeZone = TimeZone.getTimeZone("Asia/Aden") }.format(Calendar.getInstance(TimeZone.getTimeZone("Asia/Aden")).time)

    fun defaultIqama(index: Int): Int = defaults[index]
}
