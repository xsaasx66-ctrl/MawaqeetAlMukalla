package com.example.mawaqeetalmukalla

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object PrayerRepository {
    // Approximate city-centre coordinates for Al Mukalla, Hadramout.
    private const val LAT = 14.5425
    private const val LON = 49.1242
    private const val METHOD = 3 // Muslim World League; can be changed after local verification.
    private const val PREFS = "prayer_data"

    fun refresh(context: Context): Boolean {
        return try {
            val date = PrayerData.todayDate()
            val url = URL("https://api.aladhan.com/v1/timings/$date?latitude=$LAT&longitude=$LON&method=$METHOD&school=0")
            val connection = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 12000
                readTimeout = 12000
                requestMethod = "GET"
            }
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            connection.disconnect()

            val timings = JSONObject(body).getJSONObject("data").getJSONObject("timings")
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            val mapping = mapOf(
                "Fajr" to "الفجر", "Dhuhr" to "الظهر", "Asr" to "العصر",
                "Maghrib" to "المغرب", "Isha" to "العشاء"
            )
            mapping.forEach { (key, _) ->
                val raw = timings.getString(key).substringBefore(" ")
                prefs.putString(key, raw)
            }
            prefs.putString("date", date)
            prefs.putLong("updated_at", System.currentTimeMillis())
            prefs.apply()
            true
        } catch (_: Exception) {
            false
        }
    }

    fun storedTimes(context: Context): Map<String, String> {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return listOf("Fajr", "Dhuhr", "Asr", "Maghrib", "Isha")
            .mapNotNull { key -> p.getString(key, null)?.let { key to it } }.toMap()
    }

    fun iqamaMinutes(context: Context, key: String): Int {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val defaults = mapOf("Fajr" to 20, "Dhuhr" to 15, "Asr" to 15, "Maghrib" to 10, "Isha" to 15)
        return p.getInt("iqama_$key", defaults[key] ?: 15)
    }

    fun setIqama(context: Context, key: String, value: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt("iqama_$key", value.coerceIn(1, 90)).apply()
    }
}
