package com.example.mawaqeetalmukalla

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            layoutDirection = ViewGroup.LAYOUT_DIRECTION_RTL
            gravity = Gravity.TOP
        }

        fun label(text: String, size: Float = 18f) {
            root.addView(TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(0xFF17352B.toInt())
                setPadding(0, 10, 0, 8)
            })
        }

        label("مواقيت المكلا", 25f)
        label("مواقيت الصلاة تُجلب تلقائياً للمكلا – حضرموت.")
        label("اضغط تحديث لجلب مواقيت اليوم. أضف أداة التطبيق إلى الشاشة الرئيسية لعرض العد التنازلي دون فتح التطبيق.", 15f)

        val refresh = Button(this).apply {
            text = "تحديث مواقيت الصلاة"
            setOnClickListener {
                Thread {
                    val ok = PrayerRepository.refresh(this@MainActivity)
                    runOnUiThread {
                        PrayerWidgetProvider.updateAll(this@MainActivity)
                        Toast.makeText(this@MainActivity,
                            if (ok) "تم تحديث المواقيت" else "تعذر الاتصال؛ تحقق من الإنترنت",
                            Toast.LENGTH_LONG).show()
                    }
                }.start()
            }
        }
        root.addView(refresh)

        label("تحديد مدة الأذان إلى الإقامة (بالدقائق)", 18f)
        val keys = listOf("Fajr", "Dhuhr", "Asr", "Maghrib", "Isha")
        val names = PrayerData.names
        val inputs = mutableListOf<Pair<String, EditText>>()
        keys.forEachIndexed { index, key ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            row.addView(TextView(this).apply {
                text = names[index]
                textSize = 16f
                setTextColor(0xFF17352B.toInt())
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val field = EditText(this).apply {
                inputType = 2
                setText(PrayerRepository.iqamaMinutes(this@MainActivity, key).toString())
                setEms(4)
            }
            row.addView(field)
            root.addView(row)
            inputs.add(key to field)
        }

        root.addView(Button(this).apply {
            text = "حفظ مدد الإقامة"
            setOnClickListener {
                inputs.forEach { (key, field) ->
                    val minutes = field.text.toString().toIntOrNull() ?: 15
                    PrayerRepository.setIqama(this@MainActivity, key, minutes)
                }
                PrayerWidgetProvider.updateAll(this@MainActivity)
                Toast.makeText(this@MainActivity, "تم حفظ الإعدادات", Toast.LENGTH_SHORT).show()
            }
        })

        label("طريقة الاستخدام", 18f)
        label("1) اضغط مطولاً على مساحة فارغة في الشاشة الرئيسية.\n2) اختر الأدوات أو Widgets.\n3) ابحث عن «مواقيت المكلا» وأضف الأداة.\n4) اختر الحجم المناسب.", 15f)

        setContentView(root)
    }
}
